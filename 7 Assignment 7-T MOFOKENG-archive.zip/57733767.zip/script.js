"use strict"; // interpret document contents in JavaScript strict mode




/* remove default values and formatting from state and delivery
 date selection lists */
 function removeSelectDefaults() {
 var emptyBoxes = document.getElementsByTagName("select");
 for (var i = 0; i < emptyBoxes.length; i++) {
 emptyBoxes[i].selectedIndex = -1;
 }
 }
 
 /* run setup function when page finishes loading */
 if (window.addEventListener) {
 window.addEventListener("load", removeSelectDefaults, false);
 } else if (window.attachEvent) {
 window.attachEvent("onload", removeSelectDefaults);
 }
 function geoTest() {
}
if (navigator.geolocation) {
	 navigator.geolocation.getCurrentPosition(createDirections,
	 fail, {timeout: 10000});
	 } else {
	 fail();
	 }
geoTest();

function createDirections(position) {
	clearTimeout(waitForUser);
// console.log("Longitude: " + position.coords.longitude);
// console.log("Latitude: " + position.coords.latitude);
var currPosLat = position.coords.latitude;
 var currPosLng = position.coords.longitude;
 var mapOptions = {
// center: new google.maps.LatLng(currPosLat, currPosLng),
center: new google.maps.LatLng(39.96118, -82.99879),
zoom: 12
 }
 ;
 var map = new google.maps.Map(document.getElementById("map"),
 mapOptions);
}
 function fail() {
 console.log("Geolocation information not available or not
 authorized.");
 document.getElementById("map").innerHTML =
"Unable to access your current location.";
 }
 

 
 
