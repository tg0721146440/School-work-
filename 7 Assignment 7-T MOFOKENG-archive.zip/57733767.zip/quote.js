use strict"; // interpret document contents in JavaScript strict mode


 
var formValidity = true

var fname = document.getElementbyId("firstName");
	 if (fname.valueMissing) {
	 setCustomValidity("Please fill out this field.");
 }

/* automatically check Custom message check box if user makes
 entry in customText box */

/* validate create account fieldset */
 function validateCreateAccount() {
	 var errorDiv = document.querySelector(
	 "#createAccount .errorMessage");
	 var usernameElement = document.getElementById("username");
	 var pass1Element = document.getElementById("pass1");
	 var pass2Element = document.getElementById("pass2");
	 var passwordMismatch = false;
	 var accColor = "rgb(255,233,233)";
 }
 try {
	// reset styles to valid state
	 usernameElement.style.background = "";
	 pass1Element.style.background = "";
	 pass2Element.style.background = "";
	 errorDiv.style.display = "none";
	 if ((usernameElement.value !== "" && pass1Element.value !== ""
	 && pass2Element.value !== "")) {
	 // all fields are filled
	 if (pass1Element.value !== pass2Element.value) {
		 // passwords don’t match
		 passwordMismatch = true;
		 throw "Passwords entered do not match; please reenter.";
		}
	 }
	 if (!(usernameElement.value === "" && pass1Element.value === ""
		 && pass2Element.value === "")) {
		 // not all fields are blank
		 throw "Please complete all fields to create an account.";
	 }
 }
 catch(msg) {
	errorDiv.innerHTML = msg;
	errorDiv.style.display = "block";
	if (passwordMismatch) {
	usernameElement.style.background = "";
	pass1Element.style.background = accColor;
	pass2Element.style.background = accColor;
	}	else {
	if (usernameElement.value === "") {
		usernameElement.style.background = accColorColor;
	}
	if (pass1Element.value === "") {
		pass1Element.style.background = invColor;
	}
	if (pass2Element.value === "") {
		pass2Element.style.background = invColor;
		}		
	}
	formValidity = false;
 }

 /* validate form */
 function validateForm(evt) {
	 if (evt.preventDefault) {
		evt.preventDefault(); // prevent form from submitting
	 } else {
		evt.returnValue = false; // prevent form from submitting
		in IE8
	 }
	formValidity = True; // reset value for revalidation
	validateAddress("emailAddress");
	validateAddress("emailAddress");
	validateCreateAccount();
	 // replace with calls to validation functions
 if (formValidity === true) {
	 document.getElementById("errorText").innerHTML = "";
	 document.getElementById("errorText").style.display = "none";
	 document.getElementsByTagName("form")[0].submit();
	 } else {
	 document.getElementById("errorText").innerHTML = "Please fix
	 the indicated problems and then resubmit your order.";
	 document.getElementById("errorText").style.display = "block";
	 scroll(0,0);
	 }
 }
 
/* validate address fieldsets */
 function validateAddress(fieldsetId) {
	 var inputElements = document.querySelectorAll("#" +
	 fieldsetId + " input");
	 var errorDiv = document.querySelectorAll("#" + fieldsetId +
	 " .errorMessage")[0];
	 var fieldsetValidity = true;
	 var elementCount = inputElements.length;
	 var currentElement;
 
 try {
	 for (var i = 0; i < elementCount; i++) {
		// validate all input elements in fieldset
		currentElement = inputElements[i];
		if (currentElement.value === "") {
		currentElement.style.background =
			"rgb(255,233,233)";
			fieldsetValidity = false;
		} else {
			currentElement.style.background = "white";
		}
	 }
	 currentElement = document.querySelector("#" + fieldsetId +
		" select");
	 // validate payment select element
	 if (currentElement.selectedIndex === -1) {
		currentElement.style.border = "1px solid red";
		fieldsetValidity = false;
	 } else {
		currentElement.style.border = "";
	}	
	 
	 if (fieldsetValidity === false) {
	 // throw appropriate message based on current fieldset
	if (fieldsetId === "emailAddress") {
		
			throw "Please complete Email  Address information.";
		 } else {
			throw "Please complete Email Address	information.";
		 }
		 } else {
			 errorDiv.style.display = "none";
			 errorDiv.innerHTML = "";
		 }
	}
 }
	
	catch(msg) {
		errorDiv.style.display = "block";
		errorDiv.innerHTML = msg;
		formValidity = false;
 
 
 
 var form = document.getElementsByTagName("form")[0];
	 if (form.addEventListener) {
	 form.addEventListener("submit", validateForm, false);
	 } else if (form.attachEvent) {
	 form.attachEvent("onsubmit", validateForm);
 }
 if (document.getElementById("payment ").selectedIndex === -1 {
	// code to run if the field is blank
}
function calculateVolume(length, width, height) {
	var volume = length * width * height;
	document.write(volume);
}

function createCookies(){
	var formFields =
		document.querySelectorAll("input[type=hidden],
		input[type=radio], textarea");
	var expiresDate = new Date();
	expiresDate.setDate(expiresDate.getDate() + 7);
	for (var i = 0; i < formFields.length; i++) {
		var currentValue =
		decodeURIComponent(formFields[i].value);
		currentValue = currentValue.replace(/\+/g, " ");
		document.cookie = formFields[i].name + "=" + currentValue
		+ "; expires=" + expiresDate.toUTCString();
		
	}
}
function handleSubmit(evt) {
	if (evt.preventDefault) {
		evt.preventDefault(); // prevent form from submitting
	} else {
		evt.returnValue = false; // prevent form from submitting
		in IE8
	 }
	 createCookies();
	 document.getElementsByTagName("form")[0].submit();
	}
	
	function createEventListeners() {
		var form = document.getElementsByTagName("form")[0];
		if (form.addEventListener) {
			form.addEventListener("submit", handleSubmit, false);
		} else if (form.attachEvent) {
			form.attachEvent("onsubmit", handleSubmit);
		}
	}
	 function setUpPage() {
		createEventListeners();
		populateInfo();
	}	
	
	if (window.addEventListener) {
		window.addEventListener("load", setUpPage, false);
	} else if (window.attachEvent) {
		window.attachEvent("onload", setUpPage);
	}
	
	var expiresDate = new Date();
	var username = document.getElementById("username").value;
	expiresDate.setFullYear(expiresDate.getFullYear() + 1);
	document.cookie = "username=" +
		encodeURIComponent(username) + "; expires=" +
		expiresDate.toUTCString();